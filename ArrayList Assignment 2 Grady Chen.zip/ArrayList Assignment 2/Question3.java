import java.util.ArrayList;

class Question3 {
    public static ArrayList<Integer> listMaker(int n) {
        int p = 2;
        int next = 0;

        ArrayList<Integer> nums = new ArrayList<Integer>();
        for (int i = 2; i <= n; i++) {
            nums.add(i);
        }
        while (p < nums.get(nums.size() - 1)) {
            for (int i = nums.size() - 1; i >= 0; i--) {
                if (nums.get(i) % p == 0 && nums.get(i) != p) {
                    nums.remove(i);
                }
            }
            next++;
            p = nums.get(next);
        };

        return nums;
    }

    public static ArrayList<Integer> bigInts(ArrayList<Integer> a, ArrayList<Integer> b) {
        int answer = 0;
        boolean carryOver = false;
        ArrayList<Integer> ans = new ArrayList<Integer>();
        if (a.size() >= b.size()) {
        for(int i = 0; i < a.size(); i++) {
            //System.out.println("for activated:");
            int first = a.size() - 1 - i;
            int second = b.size() - 1 - i;
            if (b.size() > i) {
                //System.out.println("if working");
                answer = a.get(first) + b.get(second);
                if (carryOver) answer++;
                //System.out.println(answer);
                ans.add(0, answer%10);
                if (answer > 9) {
                    carryOver = true;
                } else {
                    carryOver = false;
                }
            
            }
            if (b.size() <= i) {
                //System.out.println("test");
                answer = a.get(first);
                if (carryOver) answer++;
                ans.add(0, answer % 10);
                if (answer > 9) {
                    carryOver = true;
                } else {
                    carryOver = false;
                }
            }
        }
        if (carryOver) {
            ans.add(0, 1);
        }
    } else {
        for(int i = 0; i < b.size(); i++) {
            //System.out.println("for activated:");
            int first = a.size() - 1 - i;
            int second = b.size() - 1 - i;
            if (a.size() > i) {
                //System.out.println("if working");
                answer = a.get(first) + b.get(second);
                if (carryOver) {
                    answer++;
                }
                //System.out.println(answer);
                ans.add(0, answer%10);
                if (answer > 9) {
                    carryOver = true;
                } else {
                    carryOver = false;
                }
            
            }
            if (a.size() <= i) {
                //System.out.println("test");
                answer = b.get(second);
                if (carryOver) answer++;
                ans.add(0, answer % 10);
                if (answer > 9) {
                    carryOver = true;
                } else {
                    carryOver = false;
                }
            }
        }
        if (carryOver) {
            ans.add(0, 1);
        }
    }
        return ans;
    }

    private void println(String s) {
        System.out.println(s);
    }

    public static void main (String[] args) {
        ArrayList<Integer> first = new ArrayList<Integer>();
        first.add(3);
        first.add(5);
        first.add(5);
        ArrayList<Integer> second = new ArrayList<Integer>();
        second.add(2);
        second.add(9);
        second.add(5);
        second.add(4);
        System.out.println(bigInts(first, second));
    }
}
