import java.util.ArrayList;

class Question1 {
    
    public static ArrayList<Integer> listMaker(int n) {
        int p = 2;
        int next = 0;
        
        ArrayList<Integer> nums = new ArrayList<Integer>();
        for (int i = 2; i <= n; i++) {
            nums.add(i);
        }
        while (p < nums.get(nums.size() - 1)) {
            for (int i = nums.size() - 1; i >= 0; i--) {
                if (nums.get(i) % p == 0 && nums.get(i) != p) {
                    nums.remove(i);
                }
            }
            next++;
            p = nums.get(next);
        };
        
        return nums;
    }
    /*public static ArrayList<Integer> lists(ArrayList<Integer> n, int p) {
        for (int i = n.size() - 1; i >= 0; i--) {
            if (n.get(i) % p != 0) {
                n.remove(i);
            }
        }
        return n;
    }*/
    
    public static void main (String[] args) {
        System.out.println(listMaker(34));
        
    }
    
    
}
