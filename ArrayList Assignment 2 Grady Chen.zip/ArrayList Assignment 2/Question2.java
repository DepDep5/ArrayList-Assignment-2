import java.util.ArrayList;

class Question2 {
    
    public static ArrayList<Integer> listMaker(int n) {
        int p = 2;
        int next = 0;
        
        ArrayList<Integer> nums = new ArrayList<Integer>();
        for (int i = 2; i <= n; i++) {
            nums.add(i);
        }
        while (p < nums.get(nums.size() - 1)) {
            for (int i = nums.size() - 1; i >= 0; i--) {
                if (nums.get(i) % p == 0 && nums.get(i) != p) {
                    nums.remove(i);
                }
            }
            next++;
            p = nums.get(next);
        };
        
        return nums;
    }
    public static String goldBach(int n) {
        int first= 0;
        int second = 0;
        ArrayList<Integer> bach = listMaker(n);
        for (int i = bach.size() - 1; i >= 0; i--) {
            int subtracted = n - bach.get(i);
            if (bach.contains(subtracted)) {
                first = bach.get(i);
                second = subtracted;
            }
        }
        String ans = first + " + " + second + " = " + n;
        return ans;
    }
    public static void main (String[] args) {
        System.out.println(goldBach(120));
    }
    
    
}
